from sklearn.base import BaseEstimator, ClassifierMixin
import numpy as np
from xgboost import XGBClassifier
class FoldWeightedXGB(ClassifierMixin, BaseEstimator):
    def __init__(self, weighted=False, n_estimators=200, max_depth=3, learning_rate=0.1, subsample=1.0, colsample_bytree=1.0, reg_lambda=1.0, random_state=42, n_jobs=1):
        self.weighted=weighted
        self.n_estimators=n_estimators
        self.max_depth=max_depth
        self.learning_rate=learning_rate
        self.subsample=subsample
        self.colsample_bytree=colsample_bytree
        self.reg_lambda=reg_lambda
        self.random_state=random_state
        self.n_jobs=n_jobs
    def fit(self,X,y):
        a=np.asarray(y)
        pos=int((a==1).sum()); neg=int((a==0).sum())
        if not pos or not neg: raise ValueError('Se requieren ambas clases')
        self.scale_pos_weight_=neg/pos if self.weighted else 1.0
        self.model_=XGBClassifier(n_estimators=self.n_estimators,max_depth=self.max_depth,learning_rate=self.learning_rate,subsample=self.subsample,colsample_bytree=self.colsample_bytree,reg_lambda=self.reg_lambda,random_state=self.random_state,n_jobs=self.n_jobs,scale_pos_weight=self.scale_pos_weight_,objective='binary:logistic',eval_metric='logloss',tree_method='hist')
        self.model_.fit(X,y)
        self.classes_=self.model_.classes_
        self.n_features_in_=self.model_.n_features_in_
        return self
    def predict_proba(self,X): return self.model_.predict_proba(X)
    def predict(self,X): return self.model_.predict(X)
